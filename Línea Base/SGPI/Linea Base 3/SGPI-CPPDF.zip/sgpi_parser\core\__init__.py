# Submódulo core
