# Motores heurísticos offline locales
