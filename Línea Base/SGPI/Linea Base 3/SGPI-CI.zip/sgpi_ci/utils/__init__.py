"""Inicialización del paquete utils."""
