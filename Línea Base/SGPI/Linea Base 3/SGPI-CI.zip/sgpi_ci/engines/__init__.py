"""Inicialización del paquete engines."""
